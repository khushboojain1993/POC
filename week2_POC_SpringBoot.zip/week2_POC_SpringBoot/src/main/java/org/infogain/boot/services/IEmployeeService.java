package org.infogain.boot.services;

import org.infogain.boot.util.IOperations;


public interface IEmployeeService extends IOperations { 
}
