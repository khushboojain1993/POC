package org.infogain.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week2PocSpringBootApplication  { 

	public static void main(String[] args) {
		SpringApplication.run(Week2PocSpringBootApplication.class, args); 
	}
	 
}
