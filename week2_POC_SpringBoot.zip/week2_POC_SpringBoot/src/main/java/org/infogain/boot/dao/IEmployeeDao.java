package org.infogain.boot.dao;

import org.infogain.boot.model.Employee;
import org.infogain.boot.util.IOperations;

public interface IEmployeeDao extends IOperations {

}
